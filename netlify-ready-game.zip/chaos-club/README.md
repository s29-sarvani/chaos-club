# CHAOS CLUB — Netlify-ready party game

This project preserves the CHAOS CLUB visual design and six-round gameplay while moving all server behavior into the standard Netlify Function `netlify/functions/game.ts`.

## Publish with Netlify Drop

1. Sign in to Netlify in your browser.
2. Open https://app.netlify.com/drop.
3. Extract `netlify-ready-game.zip` to a folder.
4. Drag the **project folder** (the folder containing `netlify.toml`, `package.json`, `package-lock.json`, `public/`, and `netlify/`) into the Drop area. Do not drag only `public/`.
5. While signed in, Netlify detects the project and runs the configured build. The function is bundled and deployed with the site. Wait for the deploy to finish, then open the assigned `*.netlify.app` URL.

Netlify Drop needs you to be signed in to run the build for an unbuilt project. A static-only upload of `public/` would not deploy the function.

## Local build checks

Requires Node.js 20+. `npm install`, then `npm test` and `npm run build`.

## Architecture

- Frontend assets: `public/`
- Single backend endpoint: `/.netlify/functions/game`
- Serverless handler: `netlify/functions/game.ts`
- Shared game rules/scoring helper: `lib/game-engine.mjs` (kept outside the functions directory)
- Persistent records: Netlify Blobs site-wide store `chaos-club`, configured for `consistency: "strong"`
- Room updates use `setJSON` with `onlyIfNew` / `onlyIfMatch` ETag conditional writes and bounded retries to avoid silently overwriting concurrent player actions.
- No always-running server, `/api/game` rewrite, `config.path`, API keys, or manual database provisioning.

## Gameplay

Accounts persist across visits. Players create or join a six-character room code, 2–8 players share a lobby, and only the host can start or advance the match. The six rounds remain Brain Blitz, Bluff or Bust, Word Panic, Hot Takes, Chaos Twist, and Final Frenzy. The first and final trivia questions, bluff submissions/voting, word submissions/voting, majority prediction, score summaries, and winner screen are retained.

Rooms and account records are stored in Netlify Blobs. Blobs is a key/value store, not a transactional relational database; this implementation uses strong reads and ETag compare-and-swap for room writes, but very high contention should move to a transactional database.

## Testing

`npm test` includes a deterministic two-player three-round simulation (trivia, bluff/vote, word/vote), checks point changes, and verifies the final winner. `npm run build` validates frontend assets, direct function endpoint usage, function TypeScript syntax, and Netlify configuration. Netlify's deployment build performs the final esbuild packaging of the function.
