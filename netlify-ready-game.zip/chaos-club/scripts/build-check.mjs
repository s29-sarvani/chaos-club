import { access, readFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
for (const file of ['public/index.html','public/style.css','public/app.js','netlify/functions/game.ts','lib/game-engine.mjs','netlify.toml']) await access(file);
const check = spawnSync(process.execPath, ['--experimental-strip-types','--check','netlify/functions/game.ts'], { encoding:'utf8' });
if (check.status !== 0) { process.stderr.write(check.stderr); process.exit(check.status || 1); }
const app = await readFile('public/app.js','utf8');
if (!app.includes("'/.netlify/functions/game?route='")) throw new Error('Frontend is not calling the Netlify Function directly.');
if (app.includes("fetch('/api/game") || app.includes('config.path')) throw new Error('Forbidden API routing pattern found.');
const fn = await readFile('netlify/functions/game.ts','utf8');
if (!fn.includes("getStore({ name:'chaos-club', consistency:'strong' })") || !fn.includes('onlyIfMatch') || !fn.includes('onlyIfNew') || !fn.includes('setJSON')) throw new Error('Strong consistency / conditional blob writes are missing.');
if (!fn.includes('export default async')) throw new Error('Default Netlify Function handler is missing.');
const config = await readFile('netlify.toml','utf8');
if (!config.includes('publish = "public"') || !config.includes('functions = "netlify/functions"')) throw new Error('Netlify publish/function configuration is incomplete.');
console.log('Production source build checks passed: static assets, direct function URL, TypeScript syntax, and Netlify config.');
console.log('Netlify will create the deployable function bundle from netlify/functions/game.ts during its logged-in Drop build.');
