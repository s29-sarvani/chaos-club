import test from 'node:test';
import assert from 'node:assert/strict';
import { advanceRoom, rounds } from '../lib/game-engine.mjs';

function roomFor(roundIndex, submissions, entries=[]) { return {roundIndex,players:[{id:'p1',name:'Ada',score:0},{id:'p2',name:'Bea',score:0}],submissions,entries,roundStartScores:{p1:0,p2:0},status:'playing',endsAt:Date.now()+30000,results:[]}; }

test('complete three-round, two-player match calculates scores and final winner',()=>{
  assert.equal(rounds.length,6,'production game retains all six rounds');
  const game={players:[{id:'p1',name:'Ada',score:0},{id:'p2',name:'Bea',score:0}],total:0};
  // Round 1: trivia — Ada correct, Bea incorrect.
  let r=roomFor(0,{p1:{answer:'0',kind:'answer'},p2:{answer:'1',kind:'answer'}});advanceRoom(r,Date.now());game.players=r.players;assert.equal(r.status,'results');assert.ok(game.players[0].score>=100);assert.equal(game.players[1].score,0);
  // Round 2: bluff — both submit, then Ada's answer gets Bea's vote.
  r=roomFor(1,{p2:{answer:'0',kind:'vote'}},[{playerId:'p1',playerName:'Ada',answer:'a parliament of whiskers'},{playerId:'p2',playerName:'Bea',answer:'a purrliament'}]);r.players=game.players;advanceRoom(r,Date.now());assert.equal(r.players[0].score,350);assert.equal(r.players[1].score,50);
  // Round 3: word panic — the more popular answer earns points; both players vote.
  r=roomFor(2,{p1:{answer:'0',kind:'vote'},p2:{answer:'0',kind:'vote'}},[{playerId:'p1',playerName:'Ada',answer:'I brought my spreadsheet'},{playerId:'p2',playerName:'Bea',answer:'I brought my spreadsheet'}]);r.players=game.players;advanceRoom(r,Date.now());
  assert.equal(r.status,'results');assert.equal(r.players[0].score,600);assert.equal(r.players[1].score,100);
  const final=[...r.players].sort((a,b)=>b.score-a.score);assert.equal(final[0].id,'p1');assert.equal(final[0].name,'Ada');assert.ok(final[0].score>final[1].score);
});

test('bluff scoring rewards creator and correct voters without self-votes',()=>{
 const r=roomFor(1,{p2:{answer:'0',kind:'vote'}},[{playerId:'p1',playerName:'Ada',answer:'clever bluff'},{playerId:'p2',playerName:'Bea',answer:'other bluff'}]);advanceRoom(r,Date.now());assert.equal(r.players[0].score,100);assert.equal(r.players[1].score,50);
});
